from django.contrib.auth import get_user_model
from users.models import Location
from datetime import datetime
import json

User = get_user_model()

def model_to_dict(obj, fields=None, exclude=None):
    data = {}
    for field in obj._meta.fields:
        field_name = field.name
        if fields and field_name not in fields:
            continue
        if exclude and field_name in exclude:
            continue
            
        value = getattr(obj, field_name)
        if isinstance(value, datetime):
            value = value.isoformat()
        elif hasattr(value, 'pk'):
            value = value.pk
        data[field_name] = value
    return data

def export_users(user_ids=None, exclude_superusers=False):
    queryset = User.objects.all()
    
    if user_ids:
        queryset = queryset.filter(id__in=user_ids)
    if exclude_superusers:
        queryset = queryset.filter(is_superuser=False)
    
    users_data = []
    for user in queryset:
        user_data = model_to_dict(user, exclude=['password'])
        user_data['groups'] = list(user.groups.values_list('name', flat=True))
        user_data['user_permissions'] = list(user.user_permissions.values_list('codename', flat=True))
        users_data.append(user_data)
    
    return users_data

def export_locations(location_ids=None, include_users=False):
    queryset = Location.objects.all()
    
    if location_ids:
        queryset = queryset.filter(id__in=location_ids)
    
    locations_data = []
    for location in queryset:
        location_data = model_to_dict(location)
        if include_users:
            location_data['user'] = model_to_dict(location.user, exclude=['password'])
        else:
            location_data['user'] = location.user.pk if location.user else None
        locations_data.append(location_data)
    
    return locations_data