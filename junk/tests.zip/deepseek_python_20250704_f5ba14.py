from django.core.management.base import BaseCommand
from users_exporter.importer import import_locations
import json

class Command(BaseCommand):
    help = 'Import Location objects from JSON file'

    def add_arguments(self, parser):
        parser.add_argument(
            'input',
            type=str,
            help='Input file path'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Simulate import without saving'
        )
        parser.add_argument(
            '--update-existing',
            action='store_true',
            help='Update existing locations instead of skipping'
        )
        parser.add_argument(
            '--skip-user-creation',
            action='store_true',
            help='Skip user creation if not exists'
        )

    def handle(self, *args, **options):
        input_path = options['input']
        dry_run = options['dry_run']
        update_existing = options['update_existing']
        skip_user_creation = options['skip_user_creation']

        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        result = import_locations(
            data,
            dry_run=dry_run,
            update_existing=update_existing,
            skip_user_creation=skip_user_creation
        )
        
        self.stdout.write(self.style.SUCCESS(
            f"Import complete. Results:\n"
            f"Created: {result['created']}\n"
            f"Updated: {result['updated']}\n"
            f"Skipped: {result['skipped']}\n"
            f"Errors: {result['errors']}"
        ))