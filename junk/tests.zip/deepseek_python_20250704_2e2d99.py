from django.contrib.auth import get_user_model
from users.models import Location
from django.contrib.auth.models import Group, Permission
from datetime import datetime
import json

User = get_user_model()

def import_users(data, dry_run=False, update_existing=False):
    result = {
        'created': 0,
        'updated': 0,
        'skipped': 0,
        'errors': 0
    }
    
    for user_data in data:
        try:
            existing_user = User.objects.filter(username=user_data['username']).first()
            
            if existing_user:
                if not update_existing:
                    result['skipped'] += 1
                    continue
                
                if not dry_run:
                    for field, value in user_data.items():
                        if field not in ['id', 'pk', 'groups', 'user_permissions']:
                            setattr(existing_user, field, value)
                    existing_user.save()
                result['updated'] += 1
            else:
                if not dry_run:
                    user = User.objects.create(
                        username=user_data['username'],
                        email=user_data.get('email', ''),
                        first_name=user_data.get('first_name', ''),
                        last_name=user_data.get('last_name', ''),
                        is_active=user_data.get('is_active', True),
                        is_staff=user_data.get('is_staff', False),
                        is_superuser=user_data.get('is_superuser', False),
                        date_joined=datetime.fromisoformat(user_data['date_joined']),
                        # Пароль не экспортируется/импортируется по соображениям безопасности
                    )
                    
                    # Добавляем группы
                    for group_name in user_data.get('groups', []):
                        group = Group.objects.get(name=group_name)
                        user.groups.add(group)
                    
                    # Добавляем permissions
                    for perm_codename in user_data.get('user_permissions', []):
                        perm = Permission.objects.get(codename=perm_codename)
                        user.user_permissions.add(perm)
                
                result['created'] += 1
        
        except Exception as e:
            result['errors'] += 1
            continue
    
    return result

def import_locations(data, dry_run=False, update_existing=False, skip_user_creation=False):
    result = {
        'created': 0,
        'updated': 0,
        'skipped': 0,
        'errors': 0
    }
    
    for loc_data in data:
        try:
            existing_loc = Location.objects.filter(id=loc_data.get('id')).first()
            
            if existing_loc:
                if not update_existing:
                    result['skipped'] += 1
                    continue
                
                if not dry_run:
                    for field, value in loc_data.items():
                        if field not in ['id', 'pk', 'user']:
                            setattr(existing_loc, field, value)
                    
                    # Обработка пользователя
                    user_id = loc_data['user'] if isinstance(loc_data['user'], int) else loc_data['user']['id']
                    try:
                        user = User.objects.get(id=user_id)
                        existing_loc.user = user
                    except User.DoesNotExist:
                        if not skip_user_creation:
                            raise
                    
                    existing_loc.save()
                result['updated'] += 1
            else:
                if not dry_run:
                    # Обработка пользователя
                    user = None
                    if 'user' in loc_data:
                        if isinstance(loc_data['user'], dict):
                            # Импортируем пользователя рекурсивно
                            user_result = import_users([loc_data['user']], dry_run=False)
                            if user_result['created'] > 0:
                                user = User.objects.get(username=loc_data['user']['username'])
                        else:
                            try:
                                user = User.objects.get(id=loc_data['user'])
                            except User.DoesNotExist:
                                if not skip_user_creation:
                                    raise
                    
                    # Создаем локацию
                    location = Location(
                        name=loc_data['name'],
                        address=loc_data.get('address', ''),
                        latitude=loc_data.get('latitude', 0),
                        longitude=loc_data.get('longitude', 0),
                        user=user,
                        # остальные поля
                    )
                    location.save()
                
                result['created'] += 1
        
        except Exception as e:
            result['errors'] += 1
            continue
    
    return result