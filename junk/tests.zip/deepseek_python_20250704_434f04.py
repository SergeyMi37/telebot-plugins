from django.core.management.base import BaseCommand
from users_exporter.importer import import_users
import json

class Command(BaseCommand):
    help = 'Import User objects from JSON file'

    def add_arguments(self, parser):
        parser.add_argument(
            'input',
            type=str,
            help='Input file path'
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Simulate import without saving'
        )
        parser.add_argument(
            '--update-existing',
            action='store_true',
            help='Update existing users instead of skipping'
        )

    def handle(self, *args, **options):
        input_path = options['input']
        dry_run = options['dry_run']
        update_existing = options['update_existing']

        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        result = import_users(data, dry_run=dry_run, update_existing=update_existing)
        
        self.stdout.write(self.style.SUCCESS(
            f"Import complete. Results:\n"
            f"Created: {result['created']}\n"
            f"Updated: {result['updated']}\n"
            f"Skipped: {result['skipped']}\n"
            f"Errors: {result['errors']}"
        ))