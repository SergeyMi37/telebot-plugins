from django.core.management.base import BaseCommand
from users_exporter.exporter import export_users
import json

class Command(BaseCommand):
    help = 'Export User objects to JSON file'

    def add_arguments(self, parser):
        parser.add_argument(
            '--output',
            type=str,
            default='users_export.json',
            help='Output file path'
        )
        parser.add_argument(
            '--ids',
            type=int,
            nargs='+',
            help='Specific user IDs to export'
        )
        parser.add_argument(
            '--exclude-superusers',
            action='store_true',
            help='Exclude superusers from export'
        )

    def handle(self, *args, **options):
        output_path = options['output']
        user_ids = options['ids']
        exclude_superusers = options['exclude_superusers']

        data = export_users(user_ids=user_ids, exclude_superusers=exclude_superusers)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        self.stdout.write(self.style.SUCCESS(
            f'Successfully exported {len(data)} users to {output_path}'
        ))